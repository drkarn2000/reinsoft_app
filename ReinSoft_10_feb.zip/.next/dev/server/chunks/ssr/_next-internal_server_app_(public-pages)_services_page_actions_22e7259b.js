module.exports = [
"[project]/.next-internal/server/app/(public-pages)/services/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28public-pages%29_services_page_actions_22e7259b.js.map