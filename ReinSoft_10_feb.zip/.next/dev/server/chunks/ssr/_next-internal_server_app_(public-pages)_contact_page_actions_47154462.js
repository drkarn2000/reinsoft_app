module.exports = [
"[project]/.next-internal/server/app/(public-pages)/contact/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28public-pages%29_contact_page_actions_47154462.js.map