module.exports = [
"[project]/.next-internal/server/app/(public-pages)/case-studies/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28public-pages%29_case-studies_page_actions_fe1717fa.js.map