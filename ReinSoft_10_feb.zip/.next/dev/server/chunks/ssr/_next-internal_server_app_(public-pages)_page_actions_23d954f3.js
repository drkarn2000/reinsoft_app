module.exports = [
"[project]/.next-internal/server/app/(public-pages)/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_%28public-pages%29_page_actions_23d954f3.js.map