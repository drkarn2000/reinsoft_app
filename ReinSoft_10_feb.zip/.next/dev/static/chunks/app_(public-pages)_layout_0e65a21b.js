(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_df5c05c4._.js",
  "static/chunks/components_f9a36504._.js"
],
    source: "dynamic"
});
