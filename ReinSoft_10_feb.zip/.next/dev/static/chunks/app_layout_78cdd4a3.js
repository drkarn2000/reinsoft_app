(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__4b5f95e4._.css",
  "static/chunks/_77f2dbc6._.js"
],
    source: "dynamic"
});
